package com.jarvis.assistant.ai

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.jarvis.assistant.core.ActionRouter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Runs the assistant entirely on-device using MediaPipe's LLM Inference API (Gemma).
 * No network call, no API key. Replaces GroqClient.
 *
 * Since the on-device model has no native "function calling" API, we hand-roll a small
 * ReAct-style protocol: the model must reply with ONE JSON object per turn, e.g.
 *   {"tool": "none", "args": {}, "message": "Merhaba!"}
 *   {"tool": "get_weather", "args": {"location": "Istanbul"}, "message": ""}
 * We execute the tool via ActionRouter, feed the result back as the next turn, and loop
 * (bounded by MAX_TOOL_HOPS) until the model answers with tool = "none".
 */
class LocalLlmClient(
    private val context: Context,
    private val modelPath: String,
    private val actionRouter: ActionRouter,
    systemPrompt: String
) {
    private var llmInference: LlmInference? = null

    private val systemPreamble =
        "<start_of_turn>user\n$systemPrompt<end_of_turn>\n" +
            "<start_of_turn>model\n" +
            "{\"tool\": \"none\", \"args\": {}, \"message\": \"Anladım, protokole göre yalnızca JSON ile yanıt vereceğim.\"}" +
            "<end_of_turn>\n"

    /** Each element is a complete "<start_of_turn>...<end_of_turn>\n" chunk, oldest first. */
    private val history = mutableListOf<String>()

    private suspend fun ensureLoaded() = withContext(Dispatchers.IO) {
        if (llmInference == null) {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(2048)
                .setTopK(40)
                .setTemperature(0.6f)
                .setRandomSeed(0)
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
        }
    }

    suspend fun send(userText: String): String = withContext(Dispatchers.IO) {
        ensureLoaded()
        val engine = llmInference ?: return@withContext "Model yüklenemedi."

        history.add("<start_of_turn>user\n$userText<end_of_turn>\n<start_of_turn>model\n")
        trimHistory()

        repeat(MAX_TOOL_HOPS) {
            val prompt = systemPreamble + history.joinToString("")
            val raw = try {
                engine.generateResponse(prompt)
            } catch (e: Exception) {
                return@withContext "Model çalıştırılırken hata oluştu: ${e.message}"
            }

            // Close the model's own turn in history before deciding what to do next.
            history[history.size - 1] = history.last() + "$raw<end_of_turn>\n"

            val parsed = parseAction(raw)
                ?: return@withContext raw.trim().ifBlank { "..." }

            if (parsed.tool == "none" || parsed.tool.isBlank() || parsed.tool !in ToolCatalog.validNames) {
                return@withContext parsed.message.ifBlank { raw.trim() }.ifBlank { "..." }
            }

            val toolResult = actionRouter.execute(parsed.tool, parsed.args)
            history.add("<start_of_turn>user\nARAÇ SONUCU (${parsed.tool}): $toolResult<end_of_turn>\n<start_of_turn>model\n")
            trimHistory()
        }

        "İşlemi tamamlayamadım, tekrar dener misin?"
    }

    /** Keeps only the most recent turns so the prompt stays within the model's context window. */
    private fun trimHistory() {
        while (history.size > MAX_HISTORY_TURNS) {
            history.removeAt(0)
        }
    }

    private data class ParsedAction(val tool: String, val args: JSONObject, val message: String)

    /** Pulls the first {...} JSON object out of the model's raw text and parses it. */
    private fun parseAction(raw: String): ParsedAction? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start == -1 || end == -1 || end < start) return null

        return try {
            val json = JSONObject(raw.substring(start, end + 1))
            ParsedAction(
                tool = json.optString("tool", "none"),
                args = json.optJSONObject("args") ?: JSONObject(),
                message = json.optString("message", "")
            )
        } catch (e: Exception) {
            null
        }
    }

    fun close() {
        llmInference?.close()
        llmInference = null
    }

    companion object {
        private const val MAX_TOOL_HOPS = 5
        private const val MAX_HISTORY_TURNS = 12
    }
}
