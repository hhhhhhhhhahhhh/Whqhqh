package com.jarvis.assistant.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.core.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * First-run screen: the model is too large to ship inside the APK, so the user downloads
 * a .task model file once (e.g. from Hugging Face's LiteRT Community Gemma-3 1B-IT page)
 * and picks it here. We copy it into app-private storage; after that everything runs
 * fully offline, no API key and no internet needed.
 */
class ModelSetupActivity : AppCompatActivity() {

    private lateinit var config: Config
    private lateinit var statusText: TextView

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) copyModelToAppStorage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_model_setup)

        config = Config(this)
        statusText = findViewById(R.id.setupStatus)
        val pickButton = findViewById<Button>(R.id.pickModelButton)

        pickButton.setOnClickListener {
            pickModel.launch(arrayOf("*/*"))
        }
    }

    private fun copyModelToAppStorage(uri: Uri) {
        statusText.text = getString(R.string.setup_copying)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        config.modelFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    config.hasModel
                } catch (e: Exception) {
                    false
                }
            }
            if (ok) {
                startActivity(Intent(this@ModelSetupActivity, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(
                    this@ModelSetupActivity,
                    "Model kopyalanamadı, tekrar dene.",
                    Toast.LENGTH_LONG
                ).show()
                statusText.text = getString(R.string.setup_desc)
            }
        }
    }
}
