package com.jarvis.assistant.ai

/**
 * The on-device model (MediaPipe LLM Inference / Gemma) has no native "function calling"
 * API like Groq/OpenAI did. Instead we describe the tools in plain text inside the prompt
 * and ask the model to answer in a small JSON envelope that LocalLlmClient parses by hand.
 */
object ToolCatalog {

    /** Tool names the model is allowed to call. Anything else is treated as invalid/ignored. */
    val validNames = setOf(
        "open_app", "sys_info", "get_weather", "browser_control", "play_media",
        "send_whatsapp_message", "save_whatsapp_contact", "save_memory", "delete_memory",
        "get_calendar_events", "add_calendar_event", "delete_calendar_event",
        "add_reminder", "get_reminders"
    )

    /** Human-readable tool list injected into the system prompt. */
    val description: String = """
        - open_app(app_name): Yüklü bir Android uygulamasını açar.
        - sys_info(kind): Pil, RAM, depolama veya saat bilgisini döner. kind: battery, ram, disk, time veya all.
        - get_weather(location): Bir şehrin güncel hava durumunu getirir.
        - browser_control(action, query): action=open_url|search|play_youtube. URL açar, Google'da arar veya YouTube'da oynatır.
        - play_media(query, provider): YouTube veya Spotify'da içerik arar ve açar. provider: youtube veya spotify.
        - send_whatsapp_message(recipient, message): Bir kişiye WhatsApp mesaj taslağı hazırlar.
        - save_whatsapp_contact(name, phone): Sık kullanılan bir WhatsApp kişisini kaydeder.
        - save_memory(key, value): Kullanıcı hakkında hatırlanacak bir bilgiyi kalıcı olarak kaydeder.
        - delete_memory(key): Hafızadan bir kaydı siler.
        - get_calendar_events(query): Takvim etkinliklerini listeler. query: today, tomorrow, week, month.
        - add_calendar_event(title, start_iso, end_iso?): Takvime yeni etkinlik ekler. start_iso/end_iso ISO 8601 formatında.
        - delete_calendar_event(title): Başlığa göre bir takvim etkinliğini siler.
        - add_reminder(title, due_iso): Belirli bir zaman için hatırlatıcı ekler. due_iso ISO 8601 formatında.
        - get_reminders(query): Yaklaşan hatırlatıcıları listeler. query: today, upcoming.
    """.trimIndent()
}
