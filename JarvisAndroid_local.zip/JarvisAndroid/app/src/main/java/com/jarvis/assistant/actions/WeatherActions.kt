package com.jarvis.assistant.actions

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Uses Open-Meteo (no API key needed) instead of a paid weather provider,
 * so the Android build works out of the box.
 */
object WeatherActions {

    private val client = OkHttpClient()

    fun getWeather(city: String): String {
        return try {
            val geo = geocode(city) ?: return "\"$city\" için konum bulunamadı."
            val (lat, lon, resolvedName) = geo

            val url = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return "Hava durumu alınamadı."
            val json = JSONObject(body)
            val current = json.getJSONObject("current")
            val temp = current.getDouble("temperature_2m")
            val humidity = current.getInt("relative_humidity_2m")
            val wind = current.getDouble("wind_speed_10m")
            val code = current.getInt("weather_code")

            "$resolvedName: ${temp}°C, nem %$humidity, rüzgar ${wind} km/s, durum: ${weatherCodeToText(code)}"
        } catch (e: Exception) {
            "Hava durumu alınırken hata oluştu: ${e.message}"
        }
    }

    private fun geocode(city: String): Triple<Double, Double, String>? {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=${city}&count=1&language=tr"
        val request = Request.Builder().url(url).build()
        val response = client.newCall(request).execute()
        val body = response.body?.string() ?: return null
        val json = JSONObject(body)
        if (!json.has("results")) return null
        val result = json.getJSONArray("results").getJSONObject(0)
        return Triple(result.getDouble("latitude"), result.getDouble("longitude"), result.getString("name"))
    }

    private fun weatherCodeToText(code: Int): String = when (code) {
        0 -> "açık"
        1, 2, 3 -> "parçalı bulutlu"
        45, 48 -> "sisli"
        51, 53, 55 -> "çisenti"
        61, 63, 65 -> "yağmurlu"
        71, 73, 75 -> "karlı"
        80, 81, 82 -> "sağanak yağışlı"
        95, 96, 99 -> "fırtınalı"
        else -> "bilinmiyor"
    }
}
