package com.jarvis.assistant.core

import android.content.Context
import com.jarvis.assistant.actions.AppLauncher
import com.jarvis.assistant.actions.BrowserActions
import com.jarvis.assistant.actions.SystemInfoActions

/**
 * Tries to satisfy simple, common requests entirely offline (no Gemini call),
 * so the daily free-tier API quota is only spent on real conversation.
 * Returns null if nothing matched, in which case the caller should fall back
 * to GeminiClient as usual.
 */
object LocalCommandParser {

    private val openAppRegex = Regex("(.+?)\\s*(?:'?y[iı]|'?y[uü])?\\s*aç(?:sana|abilir misin)?\\.?$")
    private val weatherWords = listOf("hava durumu", "hava nasıl", "hava kaç derece")
    private val batteryWords = listOf("pil", "batarya", "şarj durumu")
    private val ramWords = listOf("ram", "hafıza durumu", "bellek durumu")
    private val timeWords = listOf("saat kaç", "saat ne")

    fun tryHandle(context: Context, text: String): String? {
        val normalized = text.trim().lowercase().replace("i̇", "i")

        // "Spotify'ı aç", "google aç" gibi
        openAppRegex.find(normalized)?.let { match ->
            val appName = match.groupValues[1].trim()
            if (appName.isNotBlank() && appName.split(" ").size <= 3) {
                return AppLauncher.open(context, appName)
            }
        }

        if (weatherWords.any { normalized.contains(it) }) {
            val city = extractCity(normalized) ?: "Istanbul"
            return BrowserActions.search(context, "$city hava durumu")
        }

        if (batteryWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "battery")
        }

        if (ramWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "ram")
        }

        if (timeWords.any { normalized.contains(it) }) {
            return SystemInfoActions.query(context, "time")
        }

        return null
    }

    /** Very small heuristic: "İstanbul'da hava durumu" -> "İstanbul". Falls back to null. */
    private fun extractCity(normalized: String): String? {
        val match = Regex("([a-zçğıöşü]+)('?da|'?de)\\s+hava").find(normalized)
        return match?.groupValues?.get(1)?.replaceFirstChar { it.uppercase() }
    }
}
