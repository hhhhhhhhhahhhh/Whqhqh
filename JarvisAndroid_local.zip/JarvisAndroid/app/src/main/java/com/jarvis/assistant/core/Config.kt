package com.jarvis.assistant.core

import android.content.Context
import android.content.SharedPreferences
import java.io.File

/** Stores small persistent settings on-device, and locates the local .task model file. */
class Config(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)

    var weatherDefaultCity: String?
        get() = prefs.getString(KEY_CITY, "Istanbul")
        set(value) = prefs.edit().putString(KEY_CITY, value).apply()

    /** Where the on-device model file lives once the user has picked one. */
    val modelFile: File
        get() = File(context.filesDir, "model.task")

    val hasModel: Boolean
        get() = modelFile.exists() && modelFile.length() > 0

    companion object {
        private const val KEY_CITY = "default_city"
    }
}
