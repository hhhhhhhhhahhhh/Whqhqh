# J.A.R.V.I.S — Android Sürümü

Bu klasör, masaüstü (Windows/Mac) JARVIS Python asistanının **Android uygulaması** olarak
yeniden yazılmış halidir. Kotlin + Android Studio ile derlenir. AI, **tamamen cihaz
üzerinde (offline)** çalışır — bulut API'si, API anahtarı veya internet bağlantısı
gerekmez. Bunu, Google'ın MediaPipe **LLM Inference API**'si ile bir Gemma modelini
telefonun kendi işlemcisinde çalıştırarak sağlıyoruz.

## Kurulum (Android Studio)

1. **Android Studio**'yu aç (yoksa https://developer.android.com/studio adresinden indir).
2. `File → Open` ile bu `JarvisAndroid` klasörünü seç.
3. Gradle senkronizasyonu bitene kadar bekle (ilk açılışta internet ister, bağımlılıkları indirir).
4. Telefonunu USB ile bağla (Geliştirici Seçenekleri → USB Hata Ayıklama açık) veya bir emülatör oluştur.
5. Üstteki ▶️ (Run) butonuna bas.
6. Uygulama ilk açıldığında senden bir **model dosyası** ister (bu, tek seferlik bir kurulum adımıdır):
   - Bilgisayarında/telefonunda Hugging Face'te **`litert-community/Gemma3-1B-IT`** deposunu aç
     (veya "LiteRT Community Gemma 3 1B IT" diye ara) ve `int4` (4-bit) `.task` dosyasını indir (~550MB).
   - Dosyayı telefonuna aktar (USB, Google Drive, vb. — indirdikten sonra artık internet gerekmez).
   - Uygulamadaki "Model Dosyasını Seç (.task)" düğmesine bas, dosyayı seç.
   - Uygulama dosyayı kendi özel deposuna kopyalar; bundan sonra JARVIS tamamen offline çalışır.
   - Daha güçlü bir model istersen (daha yavaş ama daha akıllı) aynı depodan Gemma 3 4B'yi de
     deneyebilirsin — `LlmInferenceOptions`'ta ekstra bir ayar gerekmez, sadece farklı bir `.task`
     dosyası seçmen yeterli.

### Not: Fonksiyon çağırma (tool calling)
Groq/OpenAI'nin aksine, cihaz-içi model API'sinin yerleşik "function calling" özelliği yoktur.
Bunun yerine `SystemPrompt` modele her yanıtını küçük bir JSON zarfı
(`{"tool": ..., "args": {...}, "message": ...}`) içinde vermesini öğretiyor;
`LocalLlmClient` bu JSON'u ayrıştırıp gerekirse `ActionRouter` üzerinden aracı çalıştırıyor.
Küçük modellerde (1B) bu protokol büyük çoğunlukla işliyor ama Groq'un 70B modeli kadar
tutarlı değildir — model bazen formatı bozabilir; böyle durumlarda JARVIS elindeki metni
olduğu gibi son cevap olarak gösterir.

Derlemek için internet ve JDK 17 gerekir (Android Studio bunu genelde otomatik indirir).

## Neler Aynı Şekilde Çalışıyor

| Özellik | Nasıl |
|---|---|
| Sesli/yazılı AI sohbet (Gemma, cihaz-içi) | `LocalLlmClient` — MediaPipe LLM Inference ile tamamen offline; masaüstündeki `main.py`'deki araç mantığının aynısı, JSON tabanlı bir protokolle |
| Uygulama açma | `AppLauncher` — yüklü uygulamalar arasında isimle arar, `PackageManager` ile açar |
| Hava durumu | `WeatherActions` — Open-Meteo (ücretsiz, API anahtarı gerekmez) |
| Sistem bilgisi (pil, RAM, depolama, saat) | `SystemInfoActions` — `BatteryManager`/`ActivityManager`/`StatFs` |
| Tarayıcı arama / URL açma | `BrowserActions` — `Intent.ACTION_VIEW` |
| YouTube / Spotify oynatma | `MediaActions` — uygulama varsa direkt açar, yoksa tarayıcıya düşer |
| WhatsApp mesajı | `WhatsAppActions` — `wa.me` linkiyle mesaj hazırlar (Android'de 3. parti uygulamalar mesajı **otomatik gönderemez**, kullanıcı dokunup göndermeli — bu bir Android/WhatsApp kısıtı) |
| Takvim & Hatırlatıcı | `CalendarActions` — Android Takvim sağlayıcısı (`CalendarContract`); hatırlatıcılar ⏰ önekiyle aynı takvime yazılır |
| Bellek (hatırlama) | `MemoryManager` — cihaz içinde JSON dosyası olarak saklanır |
| Sesli komut / TTS | `SpeechManager` — Android'in yerleşik `SpeechRecognizer` ve `TextToSpeech` API'leri |

## Bilerek Çıkarılan / Basitleştirilen Özellikler

Bunlar bilgisayara özel olduğu veya Android'de güvenlik/izin modeliyle
uyuşmadığı için bu sürüme **dahil edilmedi**:

- **Ekran analizi (`analyze_screen`)** — macOS/Windows'ta ekran görüntüsü alıp
  Gemini Vision'a gönderiyordu. Android'de bu, `MediaProjection` API'siyle
  kullanıcıdan her seferinde ekstra bir ekran kaydı izni ister; istersen ayrı
  bir adımda ekleyebiliriz.
- **Terminal komutu çalıştırma (`shell_run`)** — Android uygulamaları
  sandbox içinde çalışır, işletim sistemi düzeyinde komut çalıştırmaya
  izin vermez (ve bu zaten güvenlik açısından riskli bir özellikti).
- **Apple Takvim/Hatırlatıcılar/Music, iPhone Sağlık verisi** — bunlar zaten
  yalnızca macOS'a özeldi; Android'de karşılığı yok, en yakın eşdeğerleri
  (Android Takvim) kullanıldı.
- **YouTube kanal istatistikleri** — dahil edilmedi ama `youtube_stats.py`
  mantığı aynı şekilde bir Android aracı olarak eklenebilir.

## Klasör Yapısı

```
app/src/main/java/com/jarvis/assistant/
  ai/            Cihaz-içi LLM istemcisi (LocalLlmClient) ve araç kataloğu
  actions/       Her özelliğin Android karşılığı (open_app, weather, whatsapp, ...)
  core/          Sohbet UI mantığı, komut yönlendirme, ayarlar
  memory/        Kalıcı hafıza (JSON tabanlı)
  voice/         Sesli komut + sesli yanıt
  ui/            Model kurulum ekranı (ilk çalıştırmada .task dosyası seçimi)
```

## Notlar

- `minSdk = 26` (Android 8.0+) — güncel telefonların büyük çoğunluğunu kapsar.
- İlk çalıştırmada mikrofon, takvim ve rehber izinleri istenir.
- WhatsApp, Spotify, YouTube gibi uygulamalar telefonda yüklü değilse otomatik
  olarak tarayıcı sürümüne yönlendirilir.
